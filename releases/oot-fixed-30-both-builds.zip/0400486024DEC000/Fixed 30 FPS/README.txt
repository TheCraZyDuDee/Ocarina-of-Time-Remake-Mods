Fixed 30 FPS

Fixed 30 FPS, native time-step; tested at normal speed on the E0F3 build.

Game title ID: 0400486024DEC000
Supported main build IDs:
E0F3CCFAF50065AE4EA01EB5AEB13B1A45DA3348
33FA6C2C23848282A77E8B88A0A93F4887C55920

Install this ZIP via a supported emulator mod manager, or copy the inner
"Fixed 30 FPS" folder into load/0400486024DEC000/.
Enable only ONE FPS mod at a time. Disable Orchid built-in FPS patch.
Restart the game with the speed limiter at 100% and frame generation off.
Check the emulator log to confirm the IPS was applied. Back up saves.
No game executable or game assets are distributed.
