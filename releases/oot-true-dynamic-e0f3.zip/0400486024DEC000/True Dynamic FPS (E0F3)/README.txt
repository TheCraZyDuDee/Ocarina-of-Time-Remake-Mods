True Dynamic FPS (E0F3)

E0F3-only isolated simulation-step timing. User reports normal game speed around 10-45 actual FPS; other builds/scenes not fully tested.

Game title ID: 0400486024DEC000
Supported main build IDs:
E0F3CCFAF50065AE4EA01EB5AEB13B1A45DA3348

Install this ZIP via a supported emulator mod manager, or copy the inner
"True Dynamic FPS (E0F3)" folder into load/0400486024DEC000/.
Enable only ONE FPS mod at a time. Disable Orchid built-in FPS patch.
Restart the game with the speed limiter at 100% and frame generation off.
Check the emulator log to confirm the IPS was applied. Back up saves.
No game executable or game assets are distributed.
